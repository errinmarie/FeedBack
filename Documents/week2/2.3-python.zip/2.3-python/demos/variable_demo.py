name = "King Arthur"
quest = "seeks the holy grail"
print(name)
print(quest)

