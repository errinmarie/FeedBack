data = open('data.txt').read()
print(data)

