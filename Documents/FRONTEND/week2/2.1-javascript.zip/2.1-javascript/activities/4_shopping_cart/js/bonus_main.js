/*
  Bonus challenge: Refactor, so that using an array (list) of objects (dicts)
  something like what is contained below, it will "auto-generate" the options
  with their buttons and descriptions.
*/

let items = [
  {
    title: "Lettuce",
    description: "Lettuce deliver the finest leaves to you.",
    item: "Leaf of Lettuce",
  },
  {
    title: "Tomato",
    description: "Some same tomato, some say tomahto, we say buy them from us.",
    item: "Tomato",
  },
  {
    title: "Oats",
    description: "Some same tomato, some say tomahto, we say buy them from us.",
    item: "Oat Grain",
  },
];





