import React, { Component } from 'react';
import './Inventory.css';

class Inventory extends Component {
  render() {
    return (
      <div className="Inventory">
        <h1>Inventory</h1>
      </div>
    );
  }
}

export default Inventory;
