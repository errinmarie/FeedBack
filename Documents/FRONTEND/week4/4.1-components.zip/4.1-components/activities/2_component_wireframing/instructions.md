Go through each of the images, and discuss with the person next to you how you
might break them down into components.

1. GitHub
2. Google Slides
3. Slack
4. Reddit

If you have extra time, try doing Reddit, and Gmail

