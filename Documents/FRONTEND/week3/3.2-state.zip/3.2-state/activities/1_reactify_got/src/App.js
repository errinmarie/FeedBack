import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';

/* See instructions.txt for full instructions! */

class App extends Component {
  render() {
    return (
      <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <h1 className="App-title">Game of Thrones Quiz</h1>
        </header>
        <p className="App-intro">
          To get started, read instructions.txt, and edit <code>src/App.js</code> to resemble legacy/index.html
        </p>
      </div>
    );
  }
}

export default App;
