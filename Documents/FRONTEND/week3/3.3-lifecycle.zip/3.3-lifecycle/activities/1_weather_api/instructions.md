Weather Dashboard
----------------------

Getting started: As before, copy the node_modules directory from a
previous activity into this directory, and then get started by running:

    npm run start


Hint: src/App.js is always what we start with


Challenge #1: console.log & trying "static" dummy data
----------------------

1. Adding console.log is always a good idea. Add one to the onRefresh
method.

2. Now, try un-commenting the state variable. This will set the state to
the static, "hard-coded" Oakland example given.

3. Can you explain where each bit of data is going?

Hint for when explaining the code:
    - To read from the state:
    {this.state.XYZ}       (where XYZ is the name of a state)

Challenge #2: Implementing fetch to Open Weather Map API
----------------------

Using previous activities and cheat-sheets as a guide, add in:

1. A "fetch" to the onSubmit method. The URL, and API Key you can use is
provided as hint.

2. For now, just hard-code the location, for example to Oakland.

3. For this challenge: Just console.log the result, and ensure the result of
the fetch is showing up in the console.


Challenge #3: Add setState after fetch
----------------------

For successful fetches, we now want to do a setState to set the results
in the state and re-render the application. This is trickier than just
adding a single line. Instead the data has to be slightly transformed
before it is usable.  If you do it correctly, it should cause the page,
when clicking the "refresh" button, to show the current weather.

Hint 1: The "oaklandweather.json" file is the same as what you get from
the API. Notice how it is transformed in the default state that you
uncommented-out in Challenge #1. Your task now is to transform the data
in the same way for your setState.

Hint 2: Don't go "too deep" with this, the answer is right in front of you...


Challenge #4: Search box
----------------------

Add the ability to search for different locations.

1. Uncommenting-out the search box at the bottom of the page

2. Add in the code necessary (an onChange event, etc) to be able to type in new
locations.


Challenge #5: Search box
----------------------

Change your fetch code to use the data from the search box, and be able to look
up different locations.


Challenge #6: Handle 404s
----------------------

Experiment with the data. Write the code to gracefully handle 404
errors, such as when the user enters a non-existent location.



Bonus Code Comprehension Challenge:
----------------------

- Can you explain what the code at the top of the render() method is doing
with classes? This, incidentally, is a pattern you will see in industry.

- It's annoying to have to hit refresh. Why can't we put the fetch in the
render method? What would happen?

- Try it out, and see if you're right.


