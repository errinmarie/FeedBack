from django.apps import AppConfig


class MicroblogConfig(AppConfig):
    name = 'microblog'
