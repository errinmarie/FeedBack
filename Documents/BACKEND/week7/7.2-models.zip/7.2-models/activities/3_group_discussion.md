# ManyToMany, OneToMany, or OneToOne

Discuss with the person next to you the categorization of the following
data items:

* Authors writing Books

* Users friending other Users on a social network

* A User on a social network and their ProfilePicture

* A User on Instagram with the photos they posted

* A photo on Instagram with the comments it attracted

* A photo on Instagram with the hashtags it used
