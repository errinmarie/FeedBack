# Control flow demo

a = 1

if a == 1:
    print('a is 1!')

