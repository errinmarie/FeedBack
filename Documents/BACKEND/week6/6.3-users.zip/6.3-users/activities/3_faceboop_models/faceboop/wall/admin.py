from django.contrib import admin

# Register your models here.

# Bonus Challenge 2: TODO: Fill in code so we can see the model in the
# admin panel
