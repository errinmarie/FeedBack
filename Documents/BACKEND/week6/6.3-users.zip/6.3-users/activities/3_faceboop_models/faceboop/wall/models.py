from django.db import models

# Challenge 2: TODO Create the WallPost model here

