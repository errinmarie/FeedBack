
# We can put this test starting data in this file for keeping things cleaner,
# and use import in views to grab it.
sitters = [
    {
        "picture": "http://placehold.it/32x32",
        "age": 30,
        "first_name": "Leonor",
        "last_name": "Conner",
        "phone": "+1 (804) 424-3567",
        "address": "194 Kossuth Place, Topanga, New Mexico, 1355"
    },
    {
        "picture": "http://placehold.it/32x32",
        "age": 25,
        "first_name": "Larson",
        "last_name": "Meyer",
        "phone": "+1 (973) 488-3746",
        "address": "197 Chestnut Street, Sussex, Ohio, 8730"
    },
    {
        "picture": "http://placehold.it/32x32",
        "age": 37,
        "first_name": "Dee",
        "last_name": "Hinton",
        "phone": "+1 (922) 592-2214",
        "address": "798 Roosevelt Place, Osage, Washington, 1455"
    },
    {
        "picture": "http://placehold.it/32x32",
        "age": 29,
        "first_name": "Hooper",
        "last_name": "Cortez",
        "phone": "+1 (913) 446-2593",
        "address": "493 Huntington Street, Allensworth, Tennessee, 7278"
    },
    {
        "picture": "http://placehold.it/32x32",
        "age": 26,
        "first_name": "Kristine",
        "last_name": "Flowers",
        "phone": "+1 (860) 503-3159",
        "address": "108 Manor Court, Gracey, Nevada, 9496"
    },
    {
        "picture": "http://placehold.it/32x32",
        "age": 38,
        "first_name": "Petra",
        "last_name": "Hendrix",
        "phone": "+1 (833) 437-3126",
        "address": "495 Jerome Street, Graniteville, Guam, 9073"
    },
    {
        "picture": "http://placehold.it/32x32",
        "age": 30,
        "first_name": "Marcy",
        "last_name": "Mann",
        "phone": "+1 (800) 465-2401",
        "address": "841 Throop Avenue, Emory, South Carolina, 4763"
    }
]


dog_images = [
    "http://cdn.shibe.online/shibes/1fc9a53355b767a146fa7e6188c88ee557e77659.jpg",
    "http://cdn.shibe.online/shibes/5a654065967877df592e4a7f978a1c2230345b63.jpg",
    "http://cdn.shibe.online/shibes/68d9b869dbcb120eb51b7b5f3a7af492429fa3f9.jpg",
    "http://cdn.shibe.online/shibes/921784ac7ea962060cf6ea0ff53f2ed775bc9bca.jpg",
    "http://cdn.shibe.online/shibes/c36e7a6e58366c4b08c8777a1bb6001f4c93cb32.jpg",
    "http://cdn.shibe.online/shibes/8886bda573037750a931b6b60505cc27abcf4ee7.jpg",
    "http://cdn.shibe.online/shibes/73baf9b7691fa3f5934e48b1605d666d55a7acbc.jpg",
    "http://cdn.shibe.online/shibes/8e46317923ae14114217ea2681ecd7d35f11bcff.jpg",
    "http://cdn.shibe.online/shibes/044669aa64a312b53180b7e3ff47a45120dccdbc.jpg",
    "http://cdn.shibe.online/shibes/3b986fc4ce9cd0737c790d76d05ce8b8e6142af3.jpg",
]

