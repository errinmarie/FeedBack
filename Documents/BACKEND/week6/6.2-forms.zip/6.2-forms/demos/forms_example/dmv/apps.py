from django.apps import AppConfig


class DmvConfig(AppConfig):
    name = 'dmv'
