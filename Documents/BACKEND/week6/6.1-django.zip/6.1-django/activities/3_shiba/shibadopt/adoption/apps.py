from django.apps import AppConfig


class AdoptionConfig(AppConfig):
    name = 'adoption'
