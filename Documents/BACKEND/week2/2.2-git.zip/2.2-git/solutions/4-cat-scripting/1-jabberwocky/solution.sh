cat jabberwocky_a.txt jabberwocky_b.txt jabberwocky_c.txt > jabberwocky_complete.txt

