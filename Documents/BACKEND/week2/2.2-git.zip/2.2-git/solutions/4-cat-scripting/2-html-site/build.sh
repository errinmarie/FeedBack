cat templates/top.html content/index.html templates/bottom.html > index.html
cat templates/top.html content/contact.html templates/bottom.html > contact.html
cat templates/top.html content/projects.html templates/bottom.html > projects.html
