# DON'T EDIT THIS! Look at mod_challenge.py

print('library.py loaded')

def greeter(name='Jack'):
    print('Hi, ', name)

chorus = '''
    Don't stop believin'
    Hold on to the feelin'
    Streetlight people
'''


