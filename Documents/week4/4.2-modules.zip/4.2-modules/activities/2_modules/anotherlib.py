# DON'T EDIT THIS! Look at mod_challenge.py

print('anotherlib.py is loaded')

def func1():
    print('function 1')

def func2():
    print('function 1')


