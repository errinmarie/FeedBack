# Challenge #1
# 1. Use pipenv to create new environment in this
# directory.
# 2. Enter that environment.





# Challenge #2
# https://github.com/Robpol86/terminaltables
# 1. Use pipenv to install terminaltables
# 2. Read the online documentation to get the example terminal table working




# Challenge #3
# https://pypi.org/project/python-docx/
# 1. Use pipenv to install pyton-docx
# 2. Read the online documentation to get reading and writing to the
# example.docx working

