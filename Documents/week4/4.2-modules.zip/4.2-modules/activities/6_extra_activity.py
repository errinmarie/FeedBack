# 1. Look up the following standard Python modules:
#     a. csv
#     b. zip
#     c. math
#     d. statistics

# 2. Get an example working for each of them

