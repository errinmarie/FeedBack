from . import othermodule

print('brokenmod.submodule loaded')

