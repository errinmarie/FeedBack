# REMINDER: Only do one challenge at a time! Save and test after every one.

print('Challenge 1 -------------')
# Challenge 1:
# 1. As with the previous activity, create a new virtualenv using pipenv
# 2. Enter into that virtualenv
# 3. Install jinja2
# 4. Examine the following code. See if you can explain in your own words what
# every line is doing. Change it to say "Ready for Activity 3!" (Should be done
# without modifying the template itself.)

from jinja2 import Template

template = Template('''
{% if is_ready %}
    Ready for Activity 3!
{% else %}
    Not ready for Activity 3...
{% endif %}
''')
result = template.render(
    is_ready=False,
)
print(result)




print('Challenge 2 -------------')
# Challenge 2:
# 1. Oh yay, another one of those "spot the mistakes" problems! This time, the
# only parts of this that are broken are in the Jinja template that is doing
# looping and if statements.
# 2. Uncomment the commented-out code and observe the errors that Jinja
# generates.
# 3. Fix everything. You will know it is fixed when it loops through all 5
# movies, printing their titles, summaries, and noting movies that are
# unusually long.

import json
movies = json.load(open('movies.json'))

template_string = '''
{{ for movie in movies }}
    -------------------------------
    - { movie.title }
    Facts:
        Title: {{ movie title }}
        Summary: movie.summary
    {% if movie.length > 150 % }
        Really Long: This movie is over 2.5 hours, yikes!
    {% end %}
{{ endfor }}
'''

#movies_information_template = Template(template_string)
#result = movies_information_template.render(
#    movies=movies,
#)
#print(result)





print('Challenge 3 -------------')
# Challenge 3:
# Write the code for a new template and render it, such that it loops through
# all movies, printing out their title and runtime (labeled as minutes), so
# it looks like:

# The Shawshank Redemption | 142 min
# The Godfather | 175 min
# The Dark Knight | 152 min
# The Godfather: Part II | 202 min
# The Room | 99 min

# (Excess space is okay.)






print('Challenge 4 -------------')
# Challenge 4:
# This is tough challenge!
# 1. Write a template that loops through all the baseball players found within
# the athletics.json file, outputting their name.
# 2. If the player joined after 2010, write "newer player" after their name.
# Hint: Use player['First Year'] to access the year they joined.
# 3. Output "BOTH: Right" if they bat with their right hand AND throw with
# their right hand. Output "BOTH: Left" if they use left for both. If is a mix
# of the two, then write: "Left, Bat - Right, Throw" (as an example)
# Hint: The data is in the format of "Bat": "R", and "Throw": "L"
players = json.load(open('athletics.json'))






print('-------------')
# Bonus Challenge
# Modify the above template to generate an HTML page containing a table,
# containing the same information. Save that HTML page to output.html

