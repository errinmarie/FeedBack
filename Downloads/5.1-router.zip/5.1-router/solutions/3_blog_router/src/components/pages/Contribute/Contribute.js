import React, { Component } from 'react';
import './Contribute.css';
class Contribute extends Component {
  render() {
    return (
      <div className="Contribute">
        <h1>Contribute</h1>
        <p>Come and contribute to my cool blog!</p>
      </div>
    );
  }
}

export default Contribute;
