=========
SillySort
=========


.. image:: https://img.shields.io/pypi/v/sillysort.svg
        :target: https://pypi.python.org/pypi/sillysort

.. image:: https://img.shields.io/travis/renanEccel/sillysort.svg
        :target: https://travis-ci.org/renanEccel/sillysort

.. image:: https://readthedocs.org/projects/sillysort/badge/?version=latest
        :target: https://sillysort.readthedocs.io/en/latest/?badge=latest
        :alt: Documentation Status




Sort things in a silly way.


* Free software: MIT license
* Documentation: https://sillysort.readthedocs.io.


Features
--------

* When times of despair and grief round your table, and you need to get things ordered in a manner that no one can, this incredible package can help you. Featuring:
* silly_sort: capable of sillyning things to the higher level possible to see
* Sillynator: Under construction

Credits
-------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage


=======
History
=======

0.1.0 (2018-03-23)
------------------

* First release on PyPI.


