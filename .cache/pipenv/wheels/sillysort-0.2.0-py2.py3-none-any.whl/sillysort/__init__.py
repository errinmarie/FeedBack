# -*- coding: utf-8 -*-

"""Top-level package for SillySort."""

__author__ = """Renan Artur Lopes Eccel"""
__email__ = 'renan.eccel@gmail.com'
__version__ = '0.2.0'
