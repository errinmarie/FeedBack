Sometimes we need to check some algorithms against great streams. An example could be when you are developing algorithms for data stream such as cardinality estimators or frequency estimators.This project let you the possibility to generate great string to check your code 


